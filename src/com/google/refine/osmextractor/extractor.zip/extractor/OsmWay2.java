package com.google.refine.osmextractor.extractor;

import de.topobyte.osm4j.core.model.iface.EntityType;
import de.topobyte.osm4j.core.model.iface.OsmMetadata;
import de.topobyte.osm4j.core.model.iface.OsmTag;
import de.topobyte.osm4j.core.model.iface.OsmWay;

public interface OsmWay2 extends OsmEntity2, OsmWay {
    public int getNumberOfNodes();

    public long getNodeId(int n);

    @Override
    double[] getCenter();

    @Override
    long getId();

    @Override
    int getNumberOfTags();

    @Override
    OsmTag getTag(int n);

    @Override
    OsmMetadata getMetadata();

    @Override
    EntityType getType();
}
