package com.google.refine.osmextractor.extractor;

import com.slimjars.dist.gnu.trove.list.TLongList;
import de.topobyte.osm4j.core.model.iface.EntityType;
import de.topobyte.osm4j.core.model.iface.OsmMetadata;
import de.topobyte.osm4j.core.model.iface.OsmTag;
import de.topobyte.osm4j.core.model.iface.OsmWay;
import de.topobyte.osm4j.core.model.impl.Entity;

import java.util.List;

public class Way2 extends Entity2 implements OsmWay2{

        private final TLongList nodes;

        public Way2(long id, TLongList nodes, double[] center)
        {
            super(id, null, center);
            this.nodes = nodes;
        }

        public Way2(long id, TLongList nodes, OsmMetadata metadata, double[] center)
        {
            super(id, metadata, center);
            this.nodes = nodes;
        }

        public Way2(long id, TLongList nodes, List<? extends OsmTag> tags, double[] center)
        {
            this(id, nodes, tags, null, center);
        }

        public Way2(long id, TLongList nodes, List<? extends OsmTag> tags,
                   OsmMetadata metadata, double[] center)
        {
            super(id, tags, metadata, center);
            this.nodes = nodes;
        }

        public TLongList getNodes()
        {
            return nodes;
        }

        @Override
        public int getNumberOfNodes()
        {
            return nodes.size();
        }

        @Override
        public long getNodeId(int n)
        {
            return nodes.get(n);
        }

        @Override
        public EntityType getType()
        {
            return EntityType.Way;
        }

}
