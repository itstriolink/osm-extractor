package com.google.refine.osmextractor.extractor;

import de.topobyte.osm4j.core.model.iface.*;
import de.topobyte.osm4j.core.model.impl.Entity;

import java.util.List;

public class Relation2 extends Entity2 implements OsmRelation2 {

        private final List<? extends OsmRelationMember> members;

        public Relation2(long id, List<? extends OsmRelationMember> members, double[] center)
        {
            super(id, null, center);
            this.members = members;
        }

        public Relation2(long id, List<? extends OsmRelationMember> members,
                        OsmMetadata metadata, double[] center)
        {
            super(id, metadata, center);
            this.members = members;
        }

        public Relation2(long id, List<? extends OsmRelationMember> members,
                        List<? extends OsmTag> tags, double[] center)
        {
            this(id, members, tags, null, center);
        }

        public Relation2(long id, List<? extends OsmRelationMember> members,
                        List<? extends OsmTag> tags, OsmMetadata metadata, double[] center)
        {
            super(id, tags, metadata, center);
            this.members = members;
        }

        public List<? extends OsmRelationMember> getMembers()
        {
            return members;
        }

        @Override
        public int getNumberOfMembers()
        {
            return members.size();
        }

        @Override
        public OsmRelationMember getMember(int n)
        {
            return members.get(n);
        }

        @Override
        public EntityType getType()
        {
            return EntityType.Relation;
        }
}
