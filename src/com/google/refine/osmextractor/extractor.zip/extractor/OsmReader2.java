package com.google.refine.osmextractor.extractor;

import de.topobyte.osm4j.core.access.OsmHandler;
import de.topobyte.osm4j.core.access.OsmInputException;
import de.topobyte.osm4j.core.access.OsmReader;

public interface OsmReader2 extends OsmReader {
    public void setHandler(OsmHandler2 handler);

    public void read() throws OsmInputException;
}
