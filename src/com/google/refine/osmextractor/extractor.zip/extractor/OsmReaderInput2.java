package com.google.refine.osmextractor.extractor;

import de.topobyte.osm4j.core.access.OsmReader;

import java.io.IOException;

public interface OsmReaderInput2 {

    public void close() throws IOException;

    public OsmReader2 getReader();
}
