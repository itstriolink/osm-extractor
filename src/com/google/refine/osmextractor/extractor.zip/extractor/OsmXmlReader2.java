package com.google.refine.osmextractor.extractor;


import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import de.topobyte.osm4j.core.access.OsmHandler;
import de.topobyte.osm4j.core.access.OsmInputException;
import de.topobyte.osm4j.core.access.OsmReader;

/**
 * This is a SAX-based parser for OSM XML data.
 *
 * @author Sebastian Kuerten (sebastian@topobyte.de)
 */
public class OsmXmlReader2 implements OsmReader2
{

    private OsmHandler2 handler;

    private boolean parseMetadata;
    private InputStream inputStream;

    public OsmXmlReader2(InputStream inputStream, boolean parseMetadata)
    {
        this.inputStream = inputStream;
        this.parseMetadata = parseMetadata;
    }

    public OsmXmlReader2(File file, boolean parseMetadata)
            throws FileNotFoundException
    {
        InputStream fis = new FileInputStream(file);
        inputStream = new BufferedInputStream(fis);
        this.parseMetadata = parseMetadata;
    }

    public OsmXmlReader2(String pathname, boolean parseMetadata)
            throws FileNotFoundException
    {
        this(new File(pathname), parseMetadata);
    }

    @Override
    public void setHandler(OsmHandler2 handler)
    {
        this.handler = handler;
    }

    @Override
    public void setHandler(OsmHandler handler) {

    }

    @Override
    public void read() throws OsmInputException
    {
        SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
        SAXParser parser;
        try {
            parser = saxParserFactory.newSAXParser();
        } catch (Exception e) {
            throw new OsmInputException("error while creating xml parser", e);
        }

        Handler2 saxHandler = Handler2.createInstance(handler,
                parseMetadata);

        try {
            parser.parse(inputStream, saxHandler);
        } catch (Exception e) {
            throw new OsmInputException("error while parsing xml data", e);
        }

        try {
            handler.complete();
        } catch (IOException e) {
            throw new OsmInputException("error while completing handler", e);
        }
    }

}