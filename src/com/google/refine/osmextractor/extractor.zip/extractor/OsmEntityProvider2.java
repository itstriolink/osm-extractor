package com.google.refine.osmextractor.extractor;

import de.topobyte.osm4j.core.model.iface.OsmNode;
import de.topobyte.osm4j.core.model.iface.OsmRelation;
import de.topobyte.osm4j.core.model.iface.OsmWay;
import de.topobyte.osm4j.core.resolve.EntityNotFoundException;
import de.topobyte.osm4j.core.resolve.OsmEntityProvider;

public interface OsmEntityProvider2 extends OsmEntityProvider {
        /**
         * Get the node with the given id.
         *
         * @param id
         *            the node's id.
         * @return the node.
         *
         * @throws EntityNotFoundException
         *             if the implementation cannot return this entity.
         */
        public OsmNode2 getNode(long id) throws EntityNotFoundException;

        /**
         * Get the way with the given id.
         *
         * @param id
         *            the way's id
         * @return the way.
         *
         * @throws EntityNotFoundException
         *             if the implementation cannot return this entity.
         */
        public OsmWay2 getWay(long id) throws EntityNotFoundException;

        /**
         * Get the relation with the given id.
         *
         * @param id
         *            the relation's id.
         * @return the relation.
         *
         * @throws EntityNotFoundException
         *             if the implementation cannot return this entity.
         */
        public OsmRelation2 getRelation(long id) throws EntityNotFoundException;

}
