package com.google.refine.osmextractor.extractor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;

import com.slimjars.dist.gnu.trove.list.array.TLongArrayList;

import de.topobyte.osm4j.core.access.OsmHandler;
import de.topobyte.osm4j.core.model.iface.EntityType;
import de.topobyte.osm4j.core.model.iface.OsmMetadata;
import de.topobyte.osm4j.core.model.iface.OsmRelationMember;
import de.topobyte.osm4j.core.model.iface.OsmTag;
import de.topobyte.osm4j.core.model.impl.Bounds;
import de.topobyte.osm4j.core.model.impl.Entity;
import de.topobyte.osm4j.core.model.impl.Metadata;
import de.topobyte.osm4j.core.model.impl.Node;
import de.topobyte.osm4j.core.model.impl.Relation;
import de.topobyte.osm4j.core.model.impl.RelationMember;
import de.topobyte.osm4j.core.model.impl.Tag;
import de.topobyte.osm4j.core.model.impl.Way;
import de.topobyte.xml.dynsax.Child;
import de.topobyte.xml.dynsax.ChildType;
import de.topobyte.xml.dynsax.Data;
import de.topobyte.xml.dynsax.DynamicSaxHandler;
import de.topobyte.xml.dynsax.Element;
import de.topobyte.xml.dynsax.ParsingException;

class Handler2 extends DynamicSaxHandler
{

    static Handler2 createInstance(boolean parseMetadata)
    {
        return new Handler2(null, parseMetadata);
    }

    static Handler2 createInstance(OsmHandler2 handler,
                                   boolean parseMetadata)
    {
        return new Handler2(handler, parseMetadata);
    }

    private OsmHandler2 handler;
    private boolean parseMetadata;
    private DateParser dateParser;

    private Handler2(OsmHandler2 handler, boolean parseMetadata)
    {
        this.handler = handler;
        this.parseMetadata = parseMetadata;
        if (parseMetadata) {
            dateParser = new DateParser();
        }
        setRoot(createRoot(), true);
    }

    void setHandler(OsmHandler2 handler)
    {
        this.handler = handler;
    }

    private Element root, bounds, bound, node, way, relation;

    private static final String NAME_OSM = "osm";
    private static final String NAME_BOUNDS = "bounds";
    private static final String NAME_BOUND = "bound";
    private static final String NAME_NODE = "node";
    private static final String NAME_WAY = "way";
    private static final String NAME_RELATION = "relation";
    private static final String NAME_TAG = "tag";
    private static final String NAME_ND = "nd";
    private static final String NAME_MEMBER = "member";

    private static final String ATTR_MIN_LAT = "minlat";
    private static final String ATTR_MAX_LAT = "maxlat";
    private static final String ATTR_MIN_LON = "minlon";
    private static final String ATTR_MAX_LON = "maxlon";
    private static final String ATTR_BOX = "box";

    private static final String ATTR_ID = "id";
    private static final String ATTR_K = "k";
    private static final String ATTR_V = "v";
    private static final String ATTR_LON = "lon";
    private static final String ATTR_LAT = "lat";
    private static final String ATTR_REF = "ref";
    private static final String ATTR_TYPE = "type";
    private static final String ATTR_ROLE = "role";
    private static final String ATTR_CENTER = "center";

    private static final String ATTR_VERSION = "version";
    private static final String ATTR_TIMESTAMP = "timestamp";
    private static final String ATTR_UID = "uid";
    private static final String ATTR_USER = "user";
    private static final String ATTR_CHANGESET = "changeset";
    private static final String ATTR_VISIBLE = "visible";

    private Element createRoot()
    {
        root = new Element(NAME_OSM, false);

        // the bounds elements

        bounds = new Element(NAME_BOUNDS, false);
        bounds.addAttribute(ATTR_MIN_LON);
        bounds.addAttribute(ATTR_MAX_LON);
        bounds.addAttribute(ATTR_MIN_LAT);
        bounds.addAttribute(ATTR_MAX_LAT);

        // the bound element

        bound = new Element(NAME_BOUND, false);
        bound.addAttribute(ATTR_BOX);

        // the 3 basic types

        node = new Element(NAME_NODE, false);
        node.addAttribute(ATTR_ID);
        node.addAttribute(ATTR_LON);
        node.addAttribute(ATTR_LAT);

        way = new Element(NAME_WAY, false);
        way.addAttribute(ATTR_ID);

        relation = new Element(NAME_RELATION, false);
        relation.addAttribute(ATTR_ID);

        List<Element> entities = new ArrayList<>();
        entities.add(node);
        entities.add(way);
        entities.add(relation);

        // add to root element

        root.addChild(new Child(bounds, ChildType.IGNORE, true));
        root.addChild(new Child(bound, ChildType.IGNORE, true));
        root.addChild(new Child(node, ChildType.IGNORE, true));
        root.addChild(new Child(way, ChildType.IGNORE, true));
        root.addChild(new Child(relation, ChildType.IGNORE, true));

        // tag for each type

        Element tag = new Element(NAME_TAG, false);
        tag.addAttribute(ATTR_K);
        tag.addAttribute(ATTR_V);

        for (Element element : entities) {
            element.addChild(new Child(tag, ChildType.LIST, false));
        }

        // meta attributes for each type
        if (parseMetadata) {
            for (Element element : entities) {
                element.addAttribute(ATTR_VERSION);
                element.addAttribute(ATTR_TIMESTAMP);
                element.addAttribute(ATTR_UID);
                element.addAttribute(ATTR_USER);
                element.addAttribute(ATTR_CHANGESET);
                element.addAttribute(ATTR_VISIBLE);
            }
        }

        Element center = new Element(ATTR_CENTER, false);
        center.addAttribute("lat");
        center.addAttribute("lon");

        // way members

        Element nd = new Element(NAME_ND, false);
        nd.addAttribute(ATTR_REF);
        way.addChild(new Child(nd, ChildType.LIST, false));

        way.addChild(new Child(center, ChildType.SINGLE, false));

        // relation members

        Element member = new Element(NAME_MEMBER, false);
        member.addAttribute(ATTR_TYPE);
        member.addAttribute(ATTR_REF);
        member.addAttribute(ATTR_ROLE);
        relation.addChild(new Child(member, ChildType.LIST, false));
        relation.addChild(new Child(center, ChildType.SINGLE, false));

        return root;
    }

    @Override
    public void emit(Data data) throws ParsingException
    {
        if (data.getElement() == bounds) {
            String aMinLon = data.getAttribute(ATTR_MIN_LON);
            String aMaxLon = data.getAttribute(ATTR_MAX_LON);
            String aMinLat = data.getAttribute(ATTR_MIN_LAT);
            String aMaxLat = data.getAttribute(ATTR_MAX_LAT);
            double minLon = Double.parseDouble(aMinLon);
            double minLat = Double.parseDouble(aMinLat);
            double maxLon = Double.parseDouble(aMaxLon);
            double maxLat = Double.parseDouble(aMaxLat);
            try {
                handler.handle(new Bounds(minLon, maxLon, maxLat, minLat));
            } catch (IOException e) {
                throw new ParsingException("while handling bounds", e);
            }
        }

        if (data.getElement() == bound) {
            String aBox = data.getAttribute(ATTR_BOX);
            String[] parts = aBox.split(",");
            if (parts.length == 4) {
                double minLat = Double.parseDouble(parts[0]);
                double minLon = Double.parseDouble(parts[1]);
                double maxLat = Double.parseDouble(parts[2]);
                double maxLon = Double.parseDouble(parts[3]);
                try {
                    handler.handle(new Bounds(minLon, maxLon, maxLat, minLat));
                } catch (IOException e) {
                    throw new ParsingException("while handling bounds", e);
                }
            }
        }

        OsmMetadata metadata = null;
        if (parseMetadata) {
            String aVersion = data.getAttribute(ATTR_VERSION);
            String aTimestamp = data.getAttribute(ATTR_TIMESTAMP);
            String aUid = data.getAttribute(ATTR_UID);
            String user = data.getAttribute(ATTR_USER);
            String aChangeset = data.getAttribute(ATTR_CHANGESET);
            String aVisible = data.getAttribute(ATTR_VISIBLE);

            long uid = -1;
            if (aUid != null) {
                uid = Long.parseLong(aUid);
            }

            if (user == null) {
                user = "";
            }

            int version = -1;
            if (aVersion != null) {
                version = Integer.parseInt(aVersion);
            }

            long changeset = -1;
            if (aChangeset != null) {
                changeset = Long.parseLong(aChangeset);
            }

            long timestamp = -1;
            if (aTimestamp != null) {
                DateTime date = dateParser.parse(aTimestamp);
                timestamp = date.getMillis();
            }

            boolean visible = true;
            if (aVisible != null) {
                if (aVisible.equals("false")) {
                    visible = false;
                }
            }

            metadata = new Metadata(version, timestamp, uid, user, changeset,
                    visible);
        }

        if (data.getElement() == node) {
            String aId = data.getAttribute(ATTR_ID);
            String aLon = data.getAttribute(ATTR_LON);
            String aLat = data.getAttribute(ATTR_LAT);


            long id = Long.parseLong(aId);
            double lon = Double.parseDouble(aLon);
            double lat = Double.parseDouble(aLat);

            Node2 node = new Node2(id, lon, lat, metadata, new double[]{lat, lon});
            fillTags(node, data);

            try {
                handler.handle(node);
            } catch (IOException e) {
                throw new ParsingException("while handling node", e);
            }
        } else if (data.getElement() == way) {
            String aId = data.getAttribute(ATTR_ID);
            long id = Long.parseLong(aId);

            TLongArrayList nodes = new TLongArrayList();
            List<Data> nds = data.getList(NAME_ND);
            if (nds != null) {
                for (Data nd : nds) {
                    String aRef = nd.getAttribute(ATTR_REF);
                    long ref = Long.parseLong(aRef);
                    nodes.add(ref);
                }
            }

            Way2 way;
            Data center = data.getSingle(ATTR_CENTER);

            if (center != null && center.getAttribute("lat") != null && center.getAttribute("lon") != null) {
                String aCenterLat = center.getAttribute("lat");
                String aCenterLon = center.getAttribute("lon");
                double centerLat = Double.parseDouble(aCenterLat);
                double centerLon = Double.parseDouble(aCenterLon);

                way = new Way2(id, nodes, metadata, new double[] {centerLat, centerLon});
            } else {
                way = new Way2(id, nodes, metadata, new double[] {0.0d, 0.0d});
            }

            fillTags(way, data);

            try {
                handler.handle(way);
            } catch (IOException e) {
                throw new ParsingException("while handling way", e);
            }
        } else if (data.getElement() == relation) {
            String aId = data.getAttribute(ATTR_ID);
            long id = Long.parseLong(aId);

            List<OsmRelationMember> members = new ArrayList<>();

            List<Data> memberDs = data.getList(NAME_MEMBER);
            if (memberDs != null) {
                for (Data memberD : memberDs) {
                    String aType = memberD.getAttribute(ATTR_TYPE);
                    String aRef = memberD.getAttribute(ATTR_REF);
                    String role = memberD.getAttribute(ATTR_ROLE);

                    long ref = Long.parseLong(aRef);

                    EntityType type = null;
                    if (aType.equals("node")) {
                        type = EntityType.Node;
                    } else if (aType.equals("way")) {
                        type = EntityType.Way;
                    } else if (aType.equals("relation")) {
                        type = EntityType.Relation;
                    }

                    RelationMember member = new RelationMember(ref, type, role);
                    members.add(member);
                }
            }
            Relation2 relation;
            Data center = data.getSingle(ATTR_CENTER);

            if (center != null && center.getAttribute("lat") != null && center.getAttribute("lon") != null) {                String aCenterLat = center.getAttribute("lat");
                String aCenterLon = center.getAttribute("lon");
                double centerLat = Double.parseDouble(aCenterLat);
                double centerLon = Double.parseDouble(aCenterLon);

                relation = new Relation2(id, members, metadata, new double[] {centerLat, centerLon});
            } else {
                relation = new Relation2(id, members, metadata, new double[] {0.0d, 0.0d});
            }

            fillTags(relation, data);

            try {
                handler.handle(relation);
            } catch (IOException e) {
                throw new ParsingException("while handling relation", e);
            }
        }
    }

    private void fillTags(Entity2 entity, Data data)
    {
        List<Data> list = data.getList(NAME_TAG);
        if (list == null) {
            return;
        }

        List<OsmTag> tags = new ArrayList<>();
        for (Data child : list) {
            String k = child.getAttribute(ATTR_K);
            String v = child.getAttribute(ATTR_V);
            tags.add(new Tag(k, v));
        }
        entity.setTags(tags);
    }

}