package com.google.refine.osmextractor.extractor;

import de.topobyte.osm4j.core.model.iface.*;

public interface OsmRelation2 extends OsmEntity2, OsmRelation {
    public int getNumberOfMembers();

    public OsmRelationMember getMember(int n);

    @Override
    double[] getCenter();

    @Override
    long getId();

    @Override
    int getNumberOfTags();

    @Override
    OsmTag getTag(int n);

    @Override
    OsmMetadata getMetadata();

    @Override
    EntityType getType();
}
