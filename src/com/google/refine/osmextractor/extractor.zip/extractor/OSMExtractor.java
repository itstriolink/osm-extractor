package com.google.refine.osmextractor.extractor;

import de.topobyte.osm4j.core.access.OsmInputException;
import de.topobyte.osm4j.core.access.OsmReader;
import de.topobyte.osm4j.core.dataset.InMemoryMapDataSet;
import de.topobyte.osm4j.core.dataset.MapDataSetLoader;
import de.topobyte.osm4j.core.model.iface.OsmMetadata;
import de.topobyte.osm4j.core.model.iface.OsmRelation;
import de.topobyte.osm4j.core.model.iface.OsmWay;
import de.topobyte.osm4j.core.resolve.EntityNotFoundException;
import de.topobyte.osm4j.geometry.*;
import org.locationtech.jts.geom.*;
import org.locationtech.jts.io.WKTWriter;

import java.io.IOException;
import java.util.*;

public class OSMExtractor {
    private String overpassInstance;
    private String overpassQuery;
    private boolean includeMetadata;
    private boolean isCenter;

    private final List<OSMElement> points;
    private final List<OSMElement> lineStrings;
    private final List<OSMElement> polygons;
    private final List<OSMElement> multiPolygons;

    private final GeometryFactory geometryFactory;
    private final WayBuilder wayBuilder;
    private final RegionBuilder regionBuilder;
    private final WKTWriter wktWriter;
    private InMemoryMapDataSet2 data;


    public OSMExtractor() {
        this.points = new ArrayList<>();
        this.lineStrings = new ArrayList<>();
        this.polygons = new ArrayList<>();
        this.multiPolygons = new ArrayList<>();

        isCenter = false;
        includeMetadata = false;

        this.geometryFactory = new GeometryFactory();
        this.wayBuilder = new WayBuilder();
        this.regionBuilder = new RegionBuilder();
        this.wktWriter = new WKTWriter();
    }

    public String getOverpassInstance() {
        return overpassInstance;
    }

    public void setOverpassInstance(String overpassInstance) {
        this.overpassInstance = overpassInstance;
    }

    public boolean getIncludeMetadata() {
        return includeMetadata;
    }

    public void setIncludeMetadata(boolean includeMetadata) {
        this.includeMetadata = includeMetadata;
    }

    public boolean getIsCenter() {
        return isCenter;
    }

    public void setIsCenter(boolean isCenter) {
        this.isCenter = isCenter;
    }

    public String getOverpassQuery() {
        return overpassQuery;
    }

    public void setOverpassQuery(String overpassQuery) {
        this.overpassQuery = overpassQuery;
    }

    public List<OSMElement> getPoints() {
        return points;
    }


    public List<OSMElement> getLineStrings() {
        return lineStrings;
    }

    public List<OSMElement> getMultiLineStrings() {
        return lineStrings;
    }

    public List<OSMElement> getMultiPolygons() {
        return multiPolygons;
    }

    public void addPoint(Point point, long id, Map<String, String> tags, OsmMetadata metadata) {
        this.points.add(new OSMElement(point, id, tags, metadata));
    }

    public void addLineString(LineString lineString, long id, Map<String, String> tags, OsmMetadata metadata) {
        this.lineStrings.add(new OSMElement(lineString, id, tags, metadata));
    }

    public void addMultiLineString(MultiLineString multiLineString, long id, Map<String, String> tags, OsmMetadata metadata) {
        this.lineStrings.add(new OSMElement(multiLineString, id, tags, metadata));
    }

    public void addMultiPolygon(MultiPolygon multiPolygon, long id, Map<String, String> tags, OsmMetadata metadata) {
        this.polygons.add(new OSMElement(multiPolygon, id, tags, metadata));
    }

    public InMemoryMapDataSet2 loadData(OsmReader2 reader) throws IOException, OsmInputException {
        return this.data = MapDataSetLoader2.read(reader, true, true, true);
    }

    public int getPointsSize() {
        return this.points.size();
    }

    public int getLineStringsSize() {
        return this.lineStrings.size();
    }

    public int getMultiLineStringsSize() {
        return this.lineStrings.size();
    }

    public int getMultiPolygonsSize() {
        return this.multiPolygons.size();
    }

    public Point buildPoint(double lat, double lon) {
        if (lat > 0.0d && lon > 0.0d) {
            Coordinate coordinate = new Coordinate(lat, lon);
            return geometryFactory.createPoint(coordinate);
        } else {
            return null;
        }
    }

    public String getWKTRepresentation(Geometry g) {
        return wktWriter.write(g);
    }

    public Collection<LineString> getLine(OsmWay way) {
        List<LineString> results = new ArrayList<>();
        try {
            WayBuilderResult lines = wayBuilder.build(way, data);
            results.addAll(lines.getLineStrings());
            if (lines.getLinearRing() != null && !lines.getLinearRing().isEmpty()) {
                results.add(lines.getLinearRing());
            }
        } catch (EntityNotFoundException e) {
            // ignore
        }
        return results;
    }

    public MultiPolygon getPolygon(OsmWay way) {
        try {
            RegionBuilderResult region = regionBuilder.build(way, data);
            return region.getMultiPolygon();
        } catch (EntityNotFoundException e) {
            return null;
        }
    }

    public MultiPolygon getPolygon(OsmRelation relation) {
        try {
            RegionBuilderResult region = regionBuilder.build(relation, data);
            return region.getMultiPolygon();
        } catch (EntityNotFoundException e) {
            return null;
        }
    }
}
