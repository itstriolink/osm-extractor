package com.google.refine.osmextractor.extractor;

import com.slimjars.dist.gnu.trove.map.TLongObjectMap;
import com.slimjars.dist.gnu.trove.map.hash.TLongObjectHashMap;
import de.topobyte.osm4j.core.model.iface.OsmBounds;
import de.topobyte.osm4j.core.model.iface.OsmNode;
import de.topobyte.osm4j.core.model.iface.OsmRelation;
import de.topobyte.osm4j.core.model.iface.OsmWay;
import de.topobyte.osm4j.core.resolve.EntityNotFoundException;
import de.topobyte.osm4j.core.resolve.OsmEntityProvider;

public class InMemoryMapDataSet2  implements OsmEntityProvider2{

        private OsmBounds bounds = null;

        private TLongObjectMap<OsmNode2> nodes = new TLongObjectHashMap<>();
        private TLongObjectMap<OsmWay2> ways = new TLongObjectHashMap<>();
        private TLongObjectMap<OsmRelation2> relations = new TLongObjectHashMap<>();

        public boolean hasBounds()
        {
            return bounds != null;
        }

        public OsmBounds getBounds()
        {
            return bounds;
        }

        public void setBounds(OsmBounds bounds)
        {
            this.bounds = bounds;
        }

        /**
         * @return all nodes.
         */
        public TLongObjectMap<OsmNode2> getNodes()
        {
            return nodes;
        }

        /**
         * @return all ways.
         */
        public TLongObjectMap<OsmWay2> getWays()
        {
            return ways;
        }

        /**
         * @return all relations.
         */
        public TLongObjectMap<OsmRelation2> getRelations()
        {
            return relations;
        }

        /**
         * @param nodes
         *            set the nodes of this dataset to be these.
         */
        public void setNodes(TLongObjectMap<OsmNode2> nodes)
        {
            this.nodes = nodes;
        }

        /**
         * @param ways
         *            set the ways of this dataset to be these.
         */
        public void setWays(TLongObjectMap<OsmWay2> ways)
        {
            this.ways = ways;
        }

        /**
         * @param relations
         *            set the relations of this dataset to be these.
         */
        public void setRelations(TLongObjectMap<OsmRelation2> relations)
        {
            this.relations = relations;
        }

        @Override
        public OsmNode2 getNode(long id) throws EntityNotFoundException
        {
            OsmNode2 node = nodes.get(id);
            if (node == null) {
                throw new EntityNotFoundException(
                        "unable to find node with id: " + id);
            }
            return node;
        }

        @Override
        public OsmWay2 getWay(long id) throws EntityNotFoundException
        {
            OsmWay2 way = ways.get(id);
            if (way == null) {
                throw new EntityNotFoundException(
                        "unable to find way with id: " + id);
            }
            return way;
        }

        @Override
        public OsmRelation2 getRelation(long id) throws EntityNotFoundException
        {
            OsmRelation2 relation = relations.get(id);
            if (relation == null) {
                throw new EntityNotFoundException(
                        "unable to find relation with id: " + id);
            }
            return relation;
        }

}
