package com.google.refine.osmextractor.extractor;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class DateParser {

        private static final String[] PATTERNS = { "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd'T'HH:mm:ssZ" };

        private static final DateTimeFormatter[] PARSERS;

        static {
            PARSERS = new DateTimeFormatter[PATTERNS.length];
            for (int i = 0; i < PATTERNS.length; i++) {
                PARSERS[i] = DateTimeFormat.forPattern(PATTERNS[i]).withZoneUTC();
            }
        }

        private DateTimeFormatter current = PARSERS[0];

        public DateTime parse(String formattedDate)
        {
            try {
                return current.parseDateTime(formattedDate);
            } catch (IllegalArgumentException e) {
                // try other parsers
            }

            for (int i = 0; i < PARSERS.length; i++) {
                DateTimeFormatter parser = PARSERS[i];
                if (parser == current) {
                    continue;
                }
                try {
                    DateTime result = parser.parseDateTime(formattedDate);
                    current = parser;
                    return result;
                } catch (IllegalArgumentException e) {
                    // continue with next pattern
                }
            }

            throw new RuntimeException("Unable to parse date '" + formattedDate
                    + "'");
        }

}
