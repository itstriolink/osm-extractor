package com.google.refine.osmextractor.extractor;

import de.topobyte.osm4j.core.model.iface.OsmMetadata;
import de.topobyte.osm4j.core.model.iface.OsmTag;

import java.util.ArrayList;
import java.util.List;

public abstract class Entity2 implements OsmEntity2 {
    private long id;
    private List<? extends OsmTag> tags;
    private OsmMetadata metadata;
    private double[] center;

    public Entity2(long id, OsmMetadata metadata, double[] center) {
        this.id = id;
        this.metadata = metadata;
        this.center = center;
        tags = new ArrayList<>();
    }

    public Entity2(long id, List<? extends OsmTag> tags, OsmMetadata metadata, double[] center) {
        this.id = id;
        this.tags = tags;
        this.metadata = metadata;
        this.center = center;
    }

    @Override
    public long getId() {
        return id;
    }

    public List<? extends OsmTag> getTags() {
        return tags;
    }

    public void setTags(List<? extends OsmTag> tags) {
        this.tags = tags;
    }

    @Override
    public int getNumberOfTags() {
        return tags.size();
    }

    @Override
    public OsmTag getTag(int n) {
        return tags.get(n);
    }

    @Override
    public OsmMetadata getMetadata() {
        return metadata;
    }

    public void setMetadata(OsmMetadata metadata) {
        this.metadata = metadata;
    }

    @Override
    public double[] getCenter() {
        return center;
    }

    public void setCenter(double[] metadata) {
        this.center = center;
    }

}
