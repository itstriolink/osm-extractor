package com.google.refine.osmextractor.extractor;

import de.topobyte.osm4j.core.model.iface.EntityType;
import de.topobyte.osm4j.core.model.iface.OsmMetadata;
import de.topobyte.osm4j.core.model.iface.OsmNode;
import de.topobyte.osm4j.core.model.iface.OsmTag;

public interface OsmNode2 extends OsmEntity2, OsmNode {
    public double getLongitude();

    public double getLatitude();

    @Override
    double[] getCenter();

    @Override
    long getId();

    @Override
    int getNumberOfTags();

    @Override
    OsmTag getTag(int n);

    @Override
    OsmMetadata getMetadata();

    @Override
    EntityType getType();
}
