package com.google.refine.osmextractor.extractor;

import de.topobyte.osm4j.core.access.OsmHandler;
import de.topobyte.osm4j.core.model.iface.OsmBounds;
import de.topobyte.osm4j.core.model.iface.OsmNode;
import de.topobyte.osm4j.core.model.iface.OsmRelation;
import de.topobyte.osm4j.core.model.iface.OsmWay;

import java.io.IOException;

public interface OsmHandler2 extends OsmHandler{

    public void handle(OsmBounds bounds) throws IOException;

    public void handle(OsmNode2 node) throws IOException;

    public void handle(OsmWay2 way) throws IOException;

    public void handle(OsmRelation2 relation) throws IOException;

    public void complete() throws IOException;

}
