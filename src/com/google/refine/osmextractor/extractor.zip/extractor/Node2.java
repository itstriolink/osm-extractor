package com.google.refine.osmextractor.extractor;

import de.topobyte.osm4j.core.model.iface.EntityType;
import de.topobyte.osm4j.core.model.iface.OsmMetadata;
import de.topobyte.osm4j.core.model.iface.OsmNode;
import de.topobyte.osm4j.core.model.iface.OsmTag;
import de.topobyte.osm4j.core.model.impl.Entity;

import java.util.List;

public class Node2 extends Entity2 implements OsmNode2 {
        private final double lon;
        private final double lat;

        public Node2(long id, double lon, double lat, double[] center)
        {
            super(id, null, center);
            this.lon = lon;
            this.lat = lat;
        }

        public Node2(long id, double lon, double lat, OsmMetadata metadata, double[] center)
        {
            super(id, metadata, center);
            this.lon = lon;
            this.lat = lat;
        }

        public Node2(long id, double lon, double lat, List<? extends OsmTag> tags, double[] center)
        {
            this(id, lon, lat, tags, null, center);
        }

        public Node2(long id, double lon, double lat, List<? extends OsmTag> tags,
                    OsmMetadata metadata, double[] center)
        {
            super(id, tags, metadata, center);
            this.lon = lon;
            this.lat = lat;
        }

        @Override
        public double getLongitude()
        {
            return lon;
        }

        @Override
        public double getLatitude()
        {
            return lat;
        }

        @Override
        public EntityType getType()
        {
            return EntityType.Node;
        }

}
