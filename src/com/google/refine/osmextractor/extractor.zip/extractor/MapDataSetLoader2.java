package com.google.refine.osmextractor.extractor;

import com.slimjars.dist.gnu.trove.list.array.TLongArrayList;
import com.slimjars.dist.gnu.trove.map.TLongObjectMap;
import de.topobyte.osm4j.core.access.OsmInputException;
import de.topobyte.osm4j.core.access.OsmIterator;
import de.topobyte.osm4j.core.access.OsmIteratorInput;
import de.topobyte.osm4j.core.model.iface.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MapDataSetLoader2 {
    public static InMemoryMapDataSet2 read(OsmIteratorInput iteratorInput,
                                           boolean keepNodeTags, boolean keepWayTags, boolean keepRelationTags)
            throws IOException {
        OsmIterator iterator = iteratorInput.getIterator();
        InMemoryMapDataSet2 data = read(iterator, keepNodeTags, keepWayTags,
                keepRelationTags);
        iteratorInput.close();
        return data;
    }

    public static InMemoryMapDataSet2 read(OsmReaderInput2 readerInput,
                                           boolean keepNodeTags, boolean keepWayTags, boolean keepRelationTags)
            throws IOException, OsmInputException {
        OsmReader2 reader = readerInput.getReader();
        InMemoryMapDataSet2 data = read(reader, keepNodeTags, keepWayTags,
                keepRelationTags);
        readerInput.close();
        return data;
    }

    public static InMemoryMapDataSet2 read(OsmIterator iterator,
                                           boolean keepNodeTags, boolean keepWayTags, boolean keepRelationTags)
            throws IOException {
        InMemoryMapDataSet2 dataSet = new InMemoryMapDataSet2();

        TLongObjectMap<OsmNode2> nodes = dataSet.getNodes();
        TLongObjectMap<OsmWay2> ways = dataSet.getWays();
        TLongObjectMap<OsmRelation2> relations = dataSet.getRelations();

        if (iterator.hasBounds()) {
            dataSet.setBounds(iterator.getBounds());
        }

        while (iterator.hasNext()) {
            EntityContainer container = iterator.next();
            switch (container.getType()) {
                case Node:
                    OsmNode2 node = (OsmNode2) container.getEntity();
                    if (!keepNodeTags) {
                        node = new Node2(node.getId(), node.getLongitude(),
                                node.getLatitude(), node.getCenter());
                    }
                    nodes.put(node.getId(), node);
                    break;
                case Way:
                    OsmWay2 way = (OsmWay2) container.getEntity();
                    if (!keepWayTags) {
                        TLongArrayList ids = new TLongArrayList();
                        for (int i = 0; i < way.getNumberOfNodes(); i++) {
                            ids.add(way.getNodeId(i));
                        }
                        way = new Way2(way.getId(), ids, way.getCenter());
                    }
                    ways.put(way.getId(), way);
                    break;
                case Relation:
                    OsmRelation2 relation = (OsmRelation2) container.getEntity();
                    if (!keepRelationTags) {
                        List<OsmRelationMember> members = new ArrayList<>();
                        for (int i = 0; i < relation.getNumberOfMembers(); i++) {
                            members.add(relation.getMember(i));
                        }
                        relation = new Relation2(relation.getId(), members, relation.getCenter());
                    }
                    relations.put(relation.getId(), relation);
                    break;
            }
        }

        return dataSet;
    }

    public static InMemoryMapDataSet2 read(OsmReader2 reader,
                                           final boolean keepNodeTags, final boolean keepWayTags,
                                           final boolean keepRelationTags) throws OsmInputException {
        final InMemoryMapDataSet2 dataSet = new InMemoryMapDataSet2();

        final TLongObjectMap<OsmNode2> nodes = dataSet.getNodes();
        final TLongObjectMap<OsmWay2> ways = dataSet.getWays();
        final TLongObjectMap<OsmRelation2> relations = dataSet.getRelations();

        reader.setHandler(new OsmHandler2() {

            @Override
            public void handle(OsmBounds bounds) throws IOException {
                dataSet.setBounds(bounds);
            }

            @Override
            public void handle(OsmNode node) throws IOException {

            }

            @Override
            public void handle(OsmWay way) throws IOException {

            }

            @Override
            public void handle(OsmRelation relation) throws IOException {

            }

            @Override
            public void handle(OsmNode2 node) throws IOException {
                if (!keepNodeTags) {
                    node = new Node2(node.getId(), node.getLongitude(), node
                            .getLatitude(), node.getCenter());
                }
                nodes.put(node.getId(), node);
            }

            @Override
            public void handle(OsmWay2 way) throws IOException {
                if (!keepWayTags) {
                    TLongArrayList ids = new TLongArrayList();
                    for (int i = 0; i < way.getNumberOfNodes(); i++) {
                        ids.add(way.getNodeId(i));
                    }
                    way = new Way2(way.getId(), ids, way.getCenter());
                }
                ways.put(way.getId(), way);
            }

            @Override
            public void handle(OsmRelation2 relation) throws IOException {
                if (!keepRelationTags) {
                    List<OsmRelationMember> members = new ArrayList<>();
                    for (int i = 0; i < relation.getNumberOfMembers(); i++) {
                        members.add(relation.getMember(i));
                    }
                    relation = new Relation2(relation.getId(), members, relation.getCenter());
                }
                relations.put(relation.getId(), relation);
            }

            @Override
            public void complete() throws IOException {
                // nothing to do here
            }

        });

        reader.read();

        return dataSet;
    }

}
